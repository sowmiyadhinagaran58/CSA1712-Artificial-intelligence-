from modules.module3 import train_model

if __name__ == "__main__":
    model = train_model()
    print("Random Forest model trained successfully:", type(model).__name__)
