import numpy as np
import pandas as pd
import streamlit as st
import plotly.graph_objects as go
from sklearn.ensemble import RandomForestRegressor

KIDNEY = {"Normal": 1.00, "Mild": 0.94, "Moderate": 0.86, "Severe": 0.74}
LIVER = {"Normal": 1.00, "Mild": 0.96, "Moderate": 0.88, "Severe": 0.78}
GENETIC = {"Normal drug processing": 1.00, "Slow drug processing": 0.86, "Fast drug processing": 1.10}

FEATURES = ["Age", "Weight", "Height", "Systolic BP", "Heart rate", "Kidney", "Liver", "Genetics", "Conditions", "Allergies", "Medications"]


def vector_from_patient(p):
    return np.array([[p.get("age", 40), p.get("weight", 70), p.get("height", 165), p.get("systolic_bp", 120), p.get("heart_rate", 75), KIDNEY[p.get("kidney", "Normal")], LIVER[p.get("liver", "Normal")], GENETIC[p.get("genetics", "Normal drug processing")], len(p.get("conditions", [])), len(p.get("allergies", [])), len(p.get("medications", []))]], dtype=float)


def train_model(seed=42):
    rng = np.random.default_rng(seed)
    n = 2600
    X = np.column_stack([
        rng.uniform(18, 85, n), rng.uniform(45, 125, n), rng.uniform(145, 195, n), rng.uniform(95, 175, n), rng.uniform(50, 115, n),
        rng.choice(list(KIDNEY.values()), n), rng.choice(list(LIVER.values()), n), rng.choice(list(GENETIC.values()), n),
        rng.integers(0, 5, n), rng.integers(0, 3, n), rng.integers(0, 5, n)
    ])
    doses = rng.choice([5, 10, 15, 20, 25, 30, 35], n)
    exposure = doses * (70 / np.maximum(X[:, 1], 40)) * (1 / X[:, 5]) * (1 / X[:, 6]) * X[:, 7]
    y = 55 + 8.5 * np.tanh(exposure / 20) - 0.5 * np.abs(X[:, 0] - 40) / 10 + 0.7 * X[:, 8] + rng.normal(0, 2.5, n)
    model = RandomForestRegressor(n_estimators=160, max_depth=10, random_state=seed, n_jobs=-1)
    model.fit(X, y)
    return model


def simulate(patient, dose, model, drug_name):
    p = vector_from_patient(patient)
    base = float(model.predict(p)[0])
    kidney = KIDNEY[patient.get("kidney", "Normal")]
    liver = LIVER[patient.get("liver", "Normal")]
    genetics = GENETIC[patient.get("genetics", "Normal drug processing")]
    weight = max(float(patient.get("weight", 70)), 40)
    drug_factor = 1.03 if "Levalbuterol" in drug_name else 1.0
    exposure = dose * (70 / weight) * (1 / kidney) * (1 / liver) * genetics
    efficacy = 35 + 22 * np.tanh(exposure / 18) + (base - 55) * 0.35
    efficacy *= drug_factor
    efficacy -= 1.1 * len(patient.get("allergies", [])) * (0.15 if "Albuterol" not in drug_name else 0.2)
    risk = 4 + 0.055 * dose**1.55 + (1 - kidney) * 32 + (1 - liver) * 22 + 0.08 * max(patient.get("heart_rate", 75) - 75, 0)
    overall = efficacy - 0.72 * risk
    return {"Drug": drug_name, "Dose": dose, "Efficacy": float(np.clip(efficacy, 0, 100)), "Risk": float(np.clip(risk, 0, 100)), "Overall": float(np.clip(overall, 0, 100)), "Cmax": float(exposure * 0.82), "AUC": float(exposure * 3.2)}


def render_module3():
    st.markdown("## Module 3 — AI Drug Comparison & Dosage Prediction")
    patient = st.session_state.patient
    drugs = st.session_state.selected_drugs
    if not patient or not drugs:
        st.warning("Complete Modules 1 and 2 first.")
        return

    st.markdown("<div class='info'><b>What the AI does:</b> a Random Forest model is trained on synthetic patient-response data. The model is then combined with a transparent PK/PD-style exposure simulation to compare dose levels for the selected patient profile.</div>", unsafe_allow_html=True)

    doses = st.multiselect("Dose levels to evaluate (simulation units)", [5, 10, 15, 20, 25, 30, 35, 40], default=st.session_state.dose_levels)
    if len(doses) < 2:
        st.warning("Choose at least two dose levels.")
        return
    st.session_state.dose_levels = doses

    model = train_model()
    frames = {}
    for drug in drugs:
        rows = [simulate(patient, dose, model, drug["name"]) for dose in doses]
        frames[drug["name"]] = pd.DataFrame(rows)

    comp = []
    for name, df in frames.items():
        best = df.loc[df["Overall"].idxmax()]
        comp.append({"Drug": name, "Best simulated dose": best["Dose"], "Efficacy": best["Efficacy"], "Risk": best["Risk"], "Overall score": best["Overall"]})
    comp_df = pd.DataFrame(comp).round(2)

    st.markdown("### Patient-specific drug comparison")
    st.dataframe(comp_df, use_container_width=True, hide_index=True)
    winner = comp_df.loc[comp_df["Overall score"].idxmax(), "Drug"]
    winner_df = frames[winner]
    best = winner_df.loc[winner_df["Overall"].idxmax()]

    st.markdown(f"<div class='result'><h3>More suitable in simulation: {winner}</h3><div>The model predicts the strongest simulated benefit–risk balance for this patient profile.</div></div>", unsafe_allow_html=True)

    c1, c2, c3, c4 = st.columns(4)
    for col, label, value in [(c1, "Best simulated dose", f"{best['Dose']}"), (c2, "Simulated efficacy", f"{best['Efficacy']:.1f}%"), (c3, "Simulated risk", f"{best['Risk']:.1f}%"), (c4, "Overall score", f"{best['Overall']:.1f}")]:
        col.markdown(f"<div class='metric'><div class='metric-label'>{label}</div><div class='metric-value'>{value}</div></div>", unsafe_allow_html=True)

    st.markdown("### Dose-response analysis")
    a, b = st.columns(2)
    with a:
        fig = go.Figure()
        for name, df in frames.items():
            fig.add_trace(go.Scatter(x=df["Dose"], y=df["Efficacy"], mode="lines+markers", name=name))
        fig.update_layout(title="Dose vs Simulated Efficacy", xaxis_title="Dose (simulation units)", yaxis_title="Efficacy (%)", template="plotly_white", hovermode="x unified", height=380, margin=dict(l=20,r=20,t=55,b=20))
        st.plotly_chart(fig, use_container_width=True)
    with b:
        fig = go.Figure()
        for name, df in frames.items():
            fig.add_trace(go.Scatter(x=df["Dose"], y=df["Risk"], mode="lines+markers", name=name))
        fig.update_layout(title="Dose vs Simulated Risk", xaxis_title="Dose (simulation units)", yaxis_title="Risk (%)", template="plotly_white", hovermode="x unified", height=380, margin=dict(l=20,r=20,t=55,b=20))
        st.plotly_chart(fig, use_container_width=True)

    fig = go.Figure()
    fig.add_trace(go.Scatter(x=winner_df["Dose"], y=winner_df["Overall"], mode="lines+markers", name="Overall score", line=dict(width=3)))
    fig.add_trace(go.Scatter(x=[best["Dose"]], y=[best["Overall"]], mode="markers+text", text=["Best simulated dose"], textposition="top center", marker=dict(size=13), name="Best point"))
    fig.update_layout(title=f"Dose vs Overall Benefit–Risk Score — {winner}", xaxis_title="Dose (simulation units)", yaxis_title="Overall score", template="plotly_white", height=420, margin=dict(l=20,r=20,t=55,b=20))
    st.plotly_chart(fig, use_container_width=True)

    st.markdown("### Detailed dose table")
    st.dataframe(winner_df.round(2), use_container_width=True, hide_index=True)

    st.markdown("### AI feature importance")
    imp = pd.DataFrame({"Feature": FEATURES, "Importance": model.feature_importances_}).sort_values("Importance", ascending=False).head(8).sort_values("Importance")
    fig = go.Figure(go.Bar(x=imp["Importance"], y=imp["Feature"], orientation="h"))
    fig.update_layout(title="Top patient features used by the Random Forest", xaxis_title="Relative importance", template="plotly_white", height=380, margin=dict(l=20,r=20,t=55,b=20))
    st.plotly_chart(fig, use_container_width=True)

    if st.button("Run Virtual Clinical Trial →", type="primary", use_container_width=True):
        st.session_state.prediction = {"winner": winner, "best_dose": int(best["Dose"]), "patient": patient, "frames": frames}
        st.session_state.module = 4
        st.rerun()
