import json
from pathlib import Path
import streamlit as st

CATALOG = Path(__file__).resolve().parent.parent / "data" / "drug_catalog.json"


def load_catalog():
    with open(CATALOG, "r", encoding="utf-8") as f:
        return json.load(f)


def render_drug(drug, idx):
    with st.container(border=True):
        st.markdown(f"### {drug['name']}")
        st.markdown(f"<div class='drug-class'>{drug['class']}</div>", unsafe_allow_html=True)
        st.markdown("<div class='drug-label'>Purpose</div>", unsafe_allow_html=True)
        st.markdown(f"<div class='drug-text'>{drug['purpose']}</div>", unsafe_allow_html=True)
        st.markdown("<div class='drug-label'>Simple explanation</div>", unsafe_allow_html=True)
        st.markdown(f"<div class='drug-text'>{drug['description']}</div>", unsafe_allow_html=True)
        st.markdown("<div class='drug-label'>Common considerations</div>", unsafe_allow_html=True)
        st.markdown(f"<div class='drug-text'>{drug['considerations']}</div>", unsafe_allow_html=True)
        return st.checkbox("Select candidate", key=f"drug_{idx}")


def render_module2():
    st.markdown("## Module 2 — Treatment & Drug Selection")
    if not st.session_state.patient:
        st.warning("Complete Module 1 first.")
        return

    catalog = load_catalog()
    treatments = list(catalog.keys())
    current = st.session_state.treatment or treatments[0]

    with st.container(border=True):
        st.markdown("### Choose what you are treating")
        treatment = st.selectbox("Treatment / condition", treatments, index=treatments.index(current) if current in treatments else 0)
        drug_type = st.radio("Drug category", ["Existing Drug", "New / Experimental Drug"], horizontal=True)
        st.session_state.treatment = treatment
        st.session_state.drug_type = drug_type

    if drug_type == "Existing Drug":
        candidates = catalog.get(treatment, [])
    else:
        with st.container(border=True):
            st.markdown("### Experimental candidate")
            c1, c2 = st.columns(2)
            with c1:
                name = st.text_input("Candidate name", value="Experimental Candidate A")
                drug_class = st.text_input("Drug class", value="Experimental simulation candidate")
            with c2:
                purpose = st.text_input("Purpose", value=f"Simulation candidate for {treatment}")
                description = st.text_area("Plain-language description", value="Hypothetical candidate used only for academic simulation.")
            candidates = [{"name": name, "class": drug_class, "purpose": purpose, "description": description, "considerations": "Simulation-only candidate.", "experimental": True}]

    if not candidates:
        st.info("No curated candidate is available for this treatment area in the demo catalog.")
        return

    st.markdown("### Compare up to two candidates")
    cols = st.columns(min(3, len(candidates)))
    selected = []
    for i, drug in enumerate(candidates):
        with cols[i % len(cols)]:
            if render_drug(drug, i):
                selected.append(drug)

    if len(selected) > 2:
        st.error("Select no more than two drugs.")
        return

    if st.button("Use Selected Drug(s) for AI Analysis →", type="primary", use_container_width=True):
        if not selected:
            st.error("Select at least one candidate drug.")
            return
        st.session_state.selected_drugs = selected
        st.session_state.prediction = {}
        st.session_state.trial = {}
        st.session_state.module = 3
        st.rerun()
