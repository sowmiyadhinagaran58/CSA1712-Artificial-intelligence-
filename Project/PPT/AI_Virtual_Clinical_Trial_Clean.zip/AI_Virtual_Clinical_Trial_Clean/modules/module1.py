import streamlit as st

CONDITIONS = [
    "Asthma", "Type 2 Diabetes", "Hypertension", "Heart condition",
    "Kidney condition", "Liver condition", "Skin condition", "Infection", "Other"
]
SEVERITY = ["Mild", "Moderate", "Severe"]
REACTIONS = ["Skin rash", "Swelling", "Breathing difficulty", "Stomach symptoms", "Other", "Unknown"]


def render_module1():
    st.markdown("## Module 1 — Patient Medical Profile")
    st.caption("Build a structured patient profile. Use selections and simple fields; no free-form medical notes are required.")

    with st.container(border=True):
        st.markdown("### 1. Patient & vital information")
        c1, c2, c3, c4 = st.columns(4)
        with c1:
            patient_id = st.text_input("Patient ID", value=st.session_state.patient.get("patient_id", "P001"))
            age = st.number_input("Age", 1, 120, int(st.session_state.patient.get("age", 38)))
        with c2:
            gender = st.selectbox("Gender", ["Female", "Male", "Other", "Prefer not to say"], index=0)
            weight = st.number_input("Weight (kg)", 20.0, 250.0, float(st.session_state.patient.get("weight", 62.5)), 0.1)
        with c3:
            height = st.number_input("Height (cm)", 100.0, 230.0, float(st.session_state.patient.get("height", 163.0)), 0.1)
            systolic_bp = st.number_input("Systolic BP", 70, 220, int(st.session_state.patient.get("systolic_bp", 121)))
        with c4:
            heart_rate = st.number_input("Heart rate (bpm)", 35, 180, int(st.session_state.patient.get("heart_rate", 76)))
            bmi = weight / max((height / 100) ** 2, 0.01)
            st.metric("Calculated BMI", f"{bmi:.1f}")

    with st.container(border=True):
        st.markdown("### 2. Organ function & genetic processing category")
        c1, c2, c3 = st.columns(3)
        with c1:
            kidney = st.selectbox("Kidney category", ["Normal", "Mild", "Moderate", "Severe"])
        with c2:
            liver = st.selectbox("Liver category", ["Normal", "Mild", "Moderate", "Severe"])
        with c3:
            genetics = st.selectbox("Genetic processing", ["Normal drug processing", "Slow drug processing", "Fast drug processing"])
        st.info("These categories are simulation inputs for the academic model, not clinical severity thresholds.")

    with st.container(border=True):
        st.markdown("### 3. Existing health conditions")
        count = st.number_input("Number of conditions", 0, 6, 2, 1)
        conditions = []
        for i in range(int(count)):
            st.markdown(f"**Condition {i+1}**")
            c1, c2, c3, c4 = st.columns([2.2, 1, 1.1, 1])
            with c1:
                name = st.selectbox("Condition", CONDITIONS, key=f"condition_name_{i}")
            with c2:
                duration = st.number_input("Duration", 0, 120, 1, key=f"condition_duration_{i}")
            with c3:
                unit = st.selectbox("Unit", ["Days", "Months", "Years"], key=f"condition_unit_{i}")
            with c4:
                severity = st.selectbox("Severity", SEVERITY, key=f"condition_severity_{i}")
            conditions.append({"name": name, "duration": int(duration), "unit": unit, "severity": severity})

    with st.container(border=True):
        st.markdown("### 4. Allergies")
        allergy_flag = st.radio("Known allergy information", ["No known allergy", "Yes"], horizontal=True)
        allergies = []
        if allergy_flag == "Yes":
            c1, c2, c3 = st.columns([1.6, 1.6, 1])
            with c1:
                allergen = st.text_input("Allergy / substance", placeholder="e.g. Penicillin")
            with c2:
                reaction = st.selectbox("Reaction", REACTIONS)
            with c3:
                known_since = st.number_input("Known since (years)", 0, 100, 1)
            allergies.append({"allergen": allergen, "reaction": reaction, "known_since_years": int(known_since)})

    with st.container(border=True):
        st.markdown("### 5. Current / previous medications")
        med_count = st.number_input("Number of medications", 0, 6, 1, 1)
        meds = []
        for i in range(int(med_count)):
            st.markdown(f"**Medication {i+1}**")
            c1, c2, c3 = st.columns([1.5, 1, 1.4])
            with c1:
                name = st.text_input("Medication name", key=f"med_name_{i}", placeholder="e.g. Metformin")
            with c2:
                duration = st.number_input("Duration (months)", 0, 240, 12, key=f"med_duration_{i}")
            with c3:
                response = st.selectbox("Observed response", ["Good", "Partial", "Poor", "Unknown"], key=f"med_response_{i}")
            meds.append({"name": name, "duration_months": int(duration), "response": response})

    if st.button("Save Patient Profile & Continue →", type="primary", use_container_width=True):
        st.session_state.patient = {
            "patient_id": patient_id.strip() or "P001",
            "age": int(age), "gender": gender, "weight": float(weight), "height": float(height),
            "systolic_bp": int(systolic_bp), "heart_rate": int(heart_rate), "kidney": kidney,
            "liver": liver, "genetics": genetics, "conditions": conditions, "allergies": allergies, "medications": meds,
        }
        st.session_state.module = 2
        st.rerun()
