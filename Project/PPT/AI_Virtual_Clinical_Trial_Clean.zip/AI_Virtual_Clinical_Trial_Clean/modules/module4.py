import numpy as np
import pandas as pd
import streamlit as st
import plotly.express as px
import plotly.graph_objects as go

KIDNEY = {"Normal": 1.00, "Mild": 0.94, "Moderate": 0.86, "Severe": 0.74}
LIVER = {"Normal": 1.00, "Mild": 0.96, "Moderate": 0.88, "Severe": 0.78}


def make_virtual_patients(ref, n, rng):
    rows = []
    for i in range(n):
        rows.append({
            "Virtual Patient": f"VP-{i+1:04d}",
            "Age": int(np.clip(rng.normal(ref["age"], 8), 18, 85)),
            "Weight": float(np.clip(rng.normal(ref["weight"], 8), 40, 130)),
            "Height": float(np.clip(rng.normal(ref["height"], 7), 145, 205)),
            "Heart rate": int(np.clip(rng.normal(ref["heart_rate"], 7), 50, 120)),
            "Systolic BP": int(np.clip(rng.normal(ref["systolic_bp"], 12), 90, 180)),
            "Kidney": rng.choice(["Normal", "Mild", "Moderate", "Severe"], p=[0.58, 0.20, 0.15, 0.07]),
            "Liver": rng.choice(["Normal", "Mild", "Moderate", "Severe"], p=[0.64, 0.20, 0.11, 0.05]),
        })
    return rows


def simulate_patient(vp, dose, rng):
    kidney = KIDNEY[vp["Kidney"]]
    liver = LIVER[vp["Liver"]]
    exposure = dose * (70 / vp["Weight"]) * (1 / kidney) * (1 / liver)
    efficacy = 34 + 22 * np.tanh(exposure / 18) - 0.08 * abs(vp["Age"] - 40) + rng.normal(0, 3.2)
    risk = 4 + 0.055 * dose**1.55 + (1 - kidney) * 32 + (1 - liver) * 22 + 0.08 * max(vp["Heart rate"] - 75, 0) + rng.normal(0, 2.3)
    overall = efficacy - 0.72 * risk
    return float(np.clip(efficacy, 0, 100)), float(np.clip(risk, 0, 100)), float(np.clip(overall, 0, 100))


def render_module4():
    st.markdown("## Module 4 — Virtual Clinical Trial & Final Analysis")
    pred = st.session_state.prediction
    if not pred:
        st.warning("Run Module 3 first to create the trial setup.")
        return

    ref = pred["patient"]
    drug = pred["winner"]
    doses = pred["frames"][drug]["Dose"].tolist()

    with st.container(border=True):
        st.markdown("### Trial setup")
        c1, c2, c3 = st.columns(3)
        with c1:
            n = st.slider("Synthetic cohort size", 100, 2000, 500, 100)
        with c2:
            seed = st.number_input("Random seed", 1, 99999, 42)
        with c3:
            st.markdown("**Selected drug**")
            st.markdown(f"### {drug}")
            st.caption(f"Dose levels: {', '.join(map(str, doses))}")

    if st.button("▶ Run Virtual Clinical Trial", type="primary", use_container_width=True):
        rng = np.random.default_rng(int(seed))
        patients = make_virtual_patients(ref, n, rng)
        rows = []
        for vp in patients:
            for dose in doses:
                efficacy, risk, overall = simulate_patient(vp, dose, rng)
                rows.append({**vp, "Dose": dose, "Efficacy": efficacy, "Risk": risk, "Overall": overall})
        df = pd.DataFrame(rows)
        summary = df.groupby("Dose")[["Efficacy", "Risk", "Overall"]].mean().reset_index()
        best = summary.loc[summary["Overall"].idxmax()]
        st.session_state.trial = {"data": df, "summary": summary, "best": best.to_dict(), "cohort": n, "seed": int(seed), "drug": drug}

    trial = st.session_state.trial
    if not trial:
        st.info("Click Run Virtual Clinical Trial to generate the synthetic population analysis.")
        return

    df = trial["data"]
    summary = trial["summary"]
    best = trial["best"]

    c1, c2, c3, c4 = st.columns(4)
    metrics = [(c1, "Virtual patients", f"{trial['cohort']}"), (c2, "Best simulated dose", f"{best['Dose']}"), (c3, "Mean efficacy", f"{best['Efficacy']:.1f}%"), (c4, "Mean risk", f"{best['Risk']:.1f}%")]
    for col, label, value in metrics:
        col.markdown(f"<div class='metric'><div class='metric-label'>{label}</div><div class='metric-value'>{value}</div></div>", unsafe_allow_html=True)

    st.markdown(f"<div class='result'><h3>Virtual Trial Final Result</h3><p><b>Drug:</b> {trial['drug']}</p><p><b>Best simulated dose:</b> {best['Dose']} units</p><p><b>Cohort:</b> {trial['cohort']} synthetic virtual patients</p><p><b>Mean simulated efficacy:</b> {best['Efficacy']:.1f}% &nbsp; | &nbsp; <b>Mean simulated risk:</b> {best['Risk']:.1f}% &nbsp; | &nbsp; <b>Mean overall score:</b> {best['Overall']:.1f}</p><p>This dose produced the strongest simulated benefit–risk balance across the synthetic cohort in this experiment.</p></div>", unsafe_allow_html=True)

    st.markdown("### Population-level dose analysis")
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=summary["Dose"], y=summary["Efficacy"], mode="lines+markers", name="Efficacy", line=dict(width=3)))
    fig.add_trace(go.Scatter(x=summary["Dose"], y=summary["Risk"], mode="lines+markers", name="Risk", line=dict(width=3)))
    fig.update_layout(title="Virtual cohort: efficacy and risk across dose levels", xaxis_title="Dose (simulation units)", yaxis_title="Mean percentage", template="plotly_white", height=430, hovermode="x unified")
    st.plotly_chart(fig, use_container_width=True)

    fig = go.Figure()
    fig.add_trace(go.Scatter(x=summary["Dose"], y=summary["Overall"], mode="lines+markers", name="Overall score", line=dict(width=3)))
    fig.add_trace(go.Scatter(x=[best["Dose"]], y=[best["Overall"]], mode="markers+text", text=["Best simulated dose"], textposition="top center", marker=dict(size=14), name="Best point"))
    fig.update_layout(title="Virtual cohort: overall benefit–risk score", xaxis_title="Dose (simulation units)", yaxis_title="Mean overall score", template="plotly_white", height=410)
    st.plotly_chart(fig, use_container_width=True)

    best_df = df[df["Dose"] == best["Dose"]].copy()
    st.markdown("### Outcome distribution at the best simulated dose")
    fig = px.histogram(best_df, x="Overall", nbins=28, marginal="box", title=f"Distribution of overall scores — dose {best['Dose']}")
    fig.update_layout(template="plotly_white", xaxis_title="Overall score", yaxis_title="Virtual patients", height=420)
    st.plotly_chart(fig, use_container_width=True)

    st.markdown("### Subgroup analysis")
    best_df["Age group"] = pd.cut(best_df["Age"], bins=[0, 40, 60, 120], labels=["18–40", "41–60", "61+"], include_lowest=True)
    a, b = st.columns(2)
    with a:
        age_sum = best_df.groupby("Age group", observed=False)["Efficacy"].mean().reset_index()
        fig = px.bar(age_sum, x="Age group", y="Efficacy", title="Mean efficacy by age group")
        fig.update_layout(template="plotly_white", height=360)
        st.plotly_chart(fig, use_container_width=True)
    with b:
        kidney_sum = best_df.groupby("Kidney")["Efficacy"].mean().reset_index()
        fig = px.bar(kidney_sum, x="Kidney", y="Efficacy", title="Mean efficacy by kidney category")
        fig.update_layout(template="plotly_white", height=360)
        st.plotly_chart(fig, use_container_width=True)

    st.markdown("### Trial comparison table")
    st.dataframe(summary.round(2), use_container_width=True, hide_index=True)
    st.markdown("### Sample virtual patients")
    st.dataframe(best_df[["Virtual Patient", "Age", "Weight", "Kidney", "Liver", "Efficacy", "Risk", "Overall"]].head(20).round(2), use_container_width=True, hide_index=True)

    csv = df.to_csv(index=False).encode("utf-8")
    st.download_button("Download virtual trial dataset (CSV)", csv, file_name="virtual_trial_results.csv", mime="text/csv", use_container_width=True)
