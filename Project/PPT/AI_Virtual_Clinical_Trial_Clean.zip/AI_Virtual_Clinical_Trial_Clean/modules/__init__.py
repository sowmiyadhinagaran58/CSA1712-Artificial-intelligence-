"""Project modules for the virtual clinical trial simulator."""
