import streamlit as st

from modules.module1 import render_module1
from modules.module2 import render_module2
from modules.module3 import render_module3
from modules.module4 import render_module4

st.set_page_config(
    page_title="AI-Based Virtual Clinical Trial Simulator",
    page_icon="🧬",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ---------------------------
# Session state
# ---------------------------
DEFAULTS = {
    "module": 1,
    "patient": {},
    "treatment": "",
    "drug_type": "Existing Drug",
    "selected_drugs": [],
    "dose_levels": [10, 15, 20, 25, 30],
    "prediction": {},
    "trial": {},
}
for key, value in DEFAULTS.items():
    if key not in st.session_state:
        st.session_state[key] = value

# ---------------------------
# Global CSS / theme
# ---------------------------
st.markdown(
    """
    <style>
    @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@600;700;800&display=swap');

    :root {
      --navy: #11324d;
      --teal: #0f8b8d;
      --teal2: #17a6a8;
      --sky: #eaf7f7;
      --ink: #17324d;
      --muted: #6b7f93;
      --line: #dfe9f0;
      --bg: #f4f8fb;
      --card: #ffffff;
      --success: #1d8a68;
      --warning: #c78312;
      --danger: #c65656;
    }

    html, body, [class*="css"] {
      font-family: 'DM Sans', sans-serif;
    }

    .stApp { background: var(--bg); }
    .block-container { padding-top: 1.4rem; padding-bottom: 2rem; max-width: 1450px; }

    [data-testid="stSidebar"] {
      background: linear-gradient(180deg, #0f2f48 0%, #123e5d 100%);
      border-right: 1px solid rgba(255,255,255,.08);
    }
    [data-testid="stSidebar"] * { color: #f5fbff !important; }
    [data-testid="stSidebar"] .stRadio > div { gap: .45rem; }
    [data-testid="stSidebar"] label {
      border-radius: 12px;
      padding: .65rem .8rem;
      transition: .15s ease;
    }
    [data-testid="stSidebar"] label:hover { background: rgba(255,255,255,.08); }

    h1, h2, h3, h4 { font-family: 'Manrope', sans-serif; color: var(--ink); }

    .hero {
      background: linear-gradient(120deg, #11324d 0%, #146b78 55%, #17a6a8 100%);
      border-radius: 22px;
      padding: 28px 32px;
      color: white;
      box-shadow: 0 12px 30px rgba(16,50,77,.16);
      margin-bottom: 20px;
    }
    .hero h1 { color: white; margin: 0; font-size: 2.3rem; }
    .hero p { margin: 7px 0 0; color: rgba(255,255,255,.88); font-size: 1rem; }
    .eyebrow { text-transform: uppercase; letter-spacing: .15em; font-size: .74rem; font-weight: 700; color: #b7f1ef; }

    .section {
      background: var(--card);
      border: 1px solid var(--line);
      border-radius: 18px;
      padding: 20px 22px;
      margin-bottom: 18px;
      box-shadow: 0 6px 20px rgba(19,54,79,.06);
    }
    .section-title { font-size: 1.12rem; font-weight: 700; color: var(--ink); margin-bottom: .3rem; }
    .section-note { color: var(--muted); font-size: .92rem; margin-bottom: 1rem; }

    .metric {
      background: white;
      border: 1px solid var(--line);
      border-radius: 16px;
      padding: 16px 18px;
      box-shadow: 0 5px 16px rgba(19,54,79,.05);
    }
    .metric-label { color: var(--muted); font-size: .78rem; text-transform: uppercase; letter-spacing: .07em; font-weight: 700; }
    .metric-value { color: var(--ink); font-size: 1.6rem; font-family: 'Manrope', sans-serif; font-weight: 800; margin-top: 4px; }

    .status-good { color: var(--success); font-weight: 700; }
    .status-warn { color: var(--warning); font-weight: 700; }
    .status-bad { color: var(--danger); font-weight: 700; }

    .result {
      background: linear-gradient(135deg, #edf9f7 0%, #ffffff 100%);
      border: 1px solid #cbece5;
      border-left: 6px solid var(--success);
      border-radius: 18px;
      padding: 22px;
      box-shadow: 0 7px 22px rgba(29,138,104,.08);
      margin: 18px 0;
    }
    .result h3 { margin-top: 0; color: #176b57; }

    .info {
      background: #eff7fb;
      border: 1px solid #d7eaf3;
      border-left: 5px solid #3f8fb5;
      border-radius: 15px;
      padding: 15px 18px;
      margin: 14px 0;
    }

    .drug-card {
      background: linear-gradient(180deg, #ffffff 0%, #f9fcfd 100%);
      border: 1px solid var(--line);
      border-radius: 18px;
      padding: 20px;
      min-height: 250px;
    }
    .drug-name { font-family: 'Manrope', sans-serif; font-weight: 800; color: var(--ink); font-size: 1.18rem; }
    .drug-class { color: var(--teal); font-weight: 700; font-size: .82rem; margin: 3px 0 12px; }
    .drug-label { color: var(--muted); font-size: .76rem; text-transform: uppercase; letter-spacing: .06em; font-weight: 700; }
    .drug-text { color: #365169; font-size: .9rem; line-height: 1.5; margin-bottom: 10px; }

    .step-chip {
      display: inline-block;
      padding: 6px 11px;
      border-radius: 999px;
      background: #e7f7f6;
      color: #116d6f;
      font-weight: 700;
      font-size: .78rem;
      margin-right: 6px;
    }

    .small-help { color: var(--muted); font-size: .84rem; }

    div.stButton > button {
      border-radius: 12px;
      font-weight: 700;
      min-height: 44px;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

# ---------------------------
# Sidebar
# ---------------------------
with st.sidebar:
    st.markdown(
        """
        <div style="padding: 10px 4px 18px 4px;">
          <div style="font-size: 1.45rem; font-family: Manrope, sans-serif; font-weight: 800;">🧬 Virtual Trial Lab</div>
          <div style="font-size:.8rem; opacity:.78; margin-top:4px;">AI-assisted research simulation</div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    module_labels = {
        1: "Module 1 — Patient Medical Profile",
        2: "Module 2 — Treatment & Drug Selection",
        3: "Module 3 — AI Drug Comparison & Dosage Prediction",
        4: "Module 4 — Virtual Clinical Trial & Final Analysis",
    }

    st.markdown("**PROJECT MODULES**")
    st.session_state.module = st.radio(
        "Project modules",
        [1, 2, 3, 4],
        index=st.session_state.module - 1,
        format_func=lambda x: module_labels[x],
        label_visibility="collapsed",
    )

    st.divider()
    pid = st.session_state.patient.get("patient_id", "Not entered")
    treatment = st.session_state.treatment or "Not selected"
    st.markdown(f"**Patient**\n\n{pid}")
    st.markdown(f"**Treatment**\n\n{treatment}")

    if st.session_state.selected_drugs:
        names = ", ".join(d["name"] for d in st.session_state.selected_drugs)
        st.markdown(f"**Candidates**\n\n{names}")

    st.divider()
    if st.button("↺ Reset project", use_container_width=True):
        for key, value in DEFAULTS.items():
            st.session_state[key] = value.copy() if isinstance(value, (dict, list)) else value
        st.rerun()

    st.markdown(
        "<div style='font-size:.75rem; line-height:1.45; opacity:.76; margin-top:16px;'>Academic prototype. Synthetic virtual patients only. Simulation outputs are not prescribing advice.</div>",
        unsafe_allow_html=True,
    )

# ---------------------------
# Header
# ---------------------------
st.markdown(
    """
    <div class="hero">
      <div class="eyebrow">Biomedical Engineering • Decision-Support Simulation</div>
      <h1>AI-Based Virtual Clinical Trial Simulator</h1>
      <p>Patient-aware drug comparison, simulated dose-response analysis, and synthetic virtual-trial evaluation.</p>
    </div>
    """,
    unsafe_allow_html=True,
)

# Progress banner
progress = {1: "Patient profile", 2: "Treatment & drug", 3: "AI prediction", 4: "Virtual trial"}
col1, col2, col3, col4 = st.columns(4)
for idx, col in enumerate([col1, col2, col3, col4], start=1):
    active = idx <= st.session_state.module
    color = "#0f8b8d" if active else "#c8d7e2"
    bg = "#e7f7f6" if active else "#f2f6f8"
    col.markdown(
        f"<div style='background:{bg}; border:1px solid {color}; border-radius:12px; padding:9px 12px; text-align:center; font-weight:700; color:{color};'>{idx} · {progress[idx]}</div>",
        unsafe_allow_html=True,
    )

st.write("")

if st.session_state.module == 1:
    render_module1()
elif st.session_state.module == 2:
    render_module2()
elif st.session_state.module == 3:
    render_module3()
else:
    render_module4()
