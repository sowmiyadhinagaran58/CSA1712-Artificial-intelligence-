def bmi(weight_kg, height_cm):
    h = height_cm / 100
    return 0 if h <= 0 else weight_kg / (h * h)
