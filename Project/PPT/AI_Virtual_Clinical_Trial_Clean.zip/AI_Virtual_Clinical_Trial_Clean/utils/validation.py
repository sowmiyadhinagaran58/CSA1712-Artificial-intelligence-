def validate_patient(patient):
    errors = []
    if not patient.get("patient_id"):
        errors.append("Patient ID is required.")
    if patient.get("age", 0) <= 0:
        errors.append("Age must be greater than zero.")
    if patient.get("weight", 0) <= 0:
        errors.append("Weight must be greater than zero.")
    if patient.get("height", 0) <= 0:
        errors.append("Height must be greater than zero.")
    return errors
