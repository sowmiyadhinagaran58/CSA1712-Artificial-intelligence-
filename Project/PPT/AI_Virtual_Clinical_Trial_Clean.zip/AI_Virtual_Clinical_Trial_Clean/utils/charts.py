"""Chart helpers are kept here for future expansion. Plotly charts are created in the module files."""
