# AI-Based Virtual Clinical Trial Simulator

Clean academic prototype for a final-year biomedical engineering project.

## Four modules
1. Patient Medical Profile
2. Treatment & Drug Selection
3. AI Drug Comparison & Dosage Prediction
4. Virtual Clinical Trial & Final Analysis

## Run on Windows PowerShell

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

Open http://localhost:8501

## Important
- No username/password or login page.
- Synthetic virtual patients only.
- Dosage values are simulation units, not prescribing recommendations.
- The drug descriptions are demo catalog content and should be clinically validated before any real-world use.
